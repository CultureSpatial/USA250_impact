
export enum ExperienceType {
  PODCAST = 'PODCAST',
  MONOLOGUE = 'MONOLOGUE',
  ANNOUNCEMENT = 'ANNOUNCEMENT',
  KEYNOTE = 'KEYNOTE'
}

export interface Speaker {
  id: string;
  name: string;
  voice: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
}

export interface ScriptLine {
  speakerId: string;
  text: string;
}

export interface ExperienceConfig {
  type: ExperienceType;
  title: string;
  description: string;
  icon: string;
  defaultSpeakers: Speaker[];
}

export interface GeneratedSnippet {
  id: string;
  title: string;
  script: ScriptLine[];
  audioUrl?: string;
  type: ExperienceType;
  createdAt: number;
}
