
import React, { useState, useCallback } from 'react';
import { EXPERIENCES } from './constants';
import { ExperienceType, GeneratedSnippet, ScriptLine, Speaker } from './types';
import { generateScript, generateMultiSpeakerAudio } from './services/geminiService';

// Components
const Header = () => (
  <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
    <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="bg-indigo-600 p-2 rounded-lg">
          <i className="fa-solid fa-microphone-lines text-white text-xl"></i>
        </div>
        <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
          AudioStory Architect
        </h1>
      </div>
      <div className="hidden md:flex items-center gap-4 text-sm font-medium text-slate-500">
        <span>Draft</span>
        <i className="fa-solid fa-chevron-right text-[10px]"></i>
        <span>Script</span>
        <i className="fa-solid fa-chevron-right text-[10px]"></i>
        <span>Synth</span>
      </div>
    </div>
  </header>
);

const App: React.FC = () => {
  const [selectedExp, setSelectedExp] = useState<ExperienceType | null>(null);
  const [topic, setTopic] = useState('');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [script, setScript] = useState<ScriptLine[] | null>(null);
  const [speakers, setSpeakers] = useState<Speaker[]>([]);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSelectExperience = (exp: ExperienceType) => {
    setSelectedExp(exp);
    const config = EXPERIENCES.find(e => e.type === exp);
    if (config) {
      setSpeakers([...config.defaultSpeakers]);
    }
    setScript(null);
    setAudioUrl(null);
  };

  const handleGenerateScript = async () => {
    if (!selectedExp || !topic) return;
    setIsGeneratingScript(true);
    setError(null);
    try {
      const generated = await generateScript(topic, selectedExp, speakers);
      setScript(generated);
    } catch (err: any) {
      setError(err.message || 'Failed to generate script');
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleGenerateAudio = async () => {
    if (!script) return;
    setIsGeneratingAudio(true);
    setError(null);
    try {
      const audioBlob = await generateMultiSpeakerAudio(script, speakers);
      const url = URL.createObjectURL(audioBlob);
      setAudioUrl(url);
    } catch (err: any) {
      setError(err.message || 'Failed to generate audio');
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  const reset = () => {
    setSelectedExp(null);
    setTopic('');
    setScript(null);
    setAudioUrl(null);
    setError(null);
  };

  const currentConfig = EXPERIENCES.find(e => e.type === selectedExp);

  return (
    <div className="min-h-screen pb-20">
      <Header />

      <main className="max-w-4xl mx-auto px-4 py-12">
        {!selectedExp ? (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="text-center space-y-4">
              <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">
                Tell a story people can hear.
              </h2>
              <p className="text-xl text-slate-500 max-w-2xl mx-auto">
                Transform outlines and topics into professional multi-voice auditory experiences.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {EXPERIENCES.map((exp) => (
                <button
                  key={exp.type}
                  onClick={() => handleSelectExperience(exp.type)}
                  className="group bg-white p-6 rounded-2xl border-2 border-slate-100 hover:border-indigo-500 hover:shadow-xl hover:shadow-indigo-500/10 transition-all text-left flex gap-5"
                >
                  <div className="w-14 h-14 shrink-0 rounded-xl bg-slate-50 group-hover:bg-indigo-50 flex items-center justify-center transition-colors">
                    <i className={`fa-solid ${exp.icon} text-2xl text-slate-400 group-hover:text-indigo-600`}></i>
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-bold text-lg text-slate-800 group-hover:text-indigo-900">{exp.title}</h3>
                    <p className="text-sm text-slate-500 leading-relaxed">{exp.description}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Navigation back */}
            <button 
              onClick={reset}
              className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors"
            >
              <i className="fa-solid fa-arrow-left"></i>
              Back to types
            </button>

            {/* Experience Status */}
            <div className="flex flex-col md:flex-row md:items-center gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="w-12 h-12 shrink-0 rounded-xl bg-indigo-50 flex items-center justify-center">
                <i className={`fa-solid ${currentConfig?.icon} text-xl text-indigo-600`}></i>
              </div>
              <div>
                <h2 className="font-bold text-lg">{currentConfig?.title}</h2>
                <p className="text-sm text-slate-500">Synthesizing audio based on your inputs</p>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center gap-3">
                <i className="fa-solid fa-circle-exclamation"></i>
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}

            {/* Topic Input */}
            {!script && (
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                  <label className="block text-sm font-bold text-slate-700">Topic or Outline</label>
                  <textarea
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Paste your source text, outlines, or Sinek-style stories here..."
                    className="w-full h-64 p-4 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all resize-none font-light text-slate-700"
                  />
                  <div className="flex justify-end">
                    <button
                      onClick={handleGenerateScript}
                      disabled={!topic || isGeneratingScript}
                      className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-600/20 active:scale-95 flex items-center gap-2"
                    >
                      {isGeneratingScript ? (
                        <>
                          <i className="fa-solid fa-circle-notch animate-spin"></i>
                          Drafting Script...
                        </>
                      ) : (
                        <>
                          <i className="fa-solid fa-wand-magic-sparkles"></i>
                          Generate Script
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Script Editor & Synthesis */}
            {script && !audioUrl && (
              <div className="space-y-6">
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                  <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                    <h3 className="font-bold text-slate-700">Review Script</h3>
                    <button onClick={() => setScript(null)} className="text-sm text-indigo-600 hover:underline">Edit Input</button>
                  </div>
                  <div className="p-6 space-y-4 max-h-[500px] overflow-y-auto">
                    {script.map((line, idx) => {
                      const speaker = speakers.find(s => s.id === line.speakerId);
                      return (
                        <div key={idx} className="flex gap-4">
                          <div className="shrink-0 pt-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                              {speaker?.name}
                            </span>
                          </div>
                          <p className="text-slate-700 leading-relaxed italic">"{line.text}"</p>
                        </div>
                      );
                    })}
                  </div>
                  <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
                    <div className="text-sm text-slate-500">
                      Voices: {speakers.map(s => s.voice).join(', ')}
                    </div>
                    <button
                      onClick={handleGenerateAudio}
                      disabled={isGeneratingAudio}
                      className="px-8 py-3 bg-violet-600 hover:bg-violet-700 disabled:bg-slate-300 text-white font-bold rounded-xl transition-all shadow-lg shadow-violet-600/20 active:scale-95 flex items-center gap-2"
                    >
                      {isGeneratingAudio ? (
                        <>
                          <i className="fa-solid fa-waveform animate-pulse"></i>
                          Synthesizing Audio...
                        </>
                      ) : (
                        <>
                          <i className="fa-solid fa-play"></i>
                          Generate Audio
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Final Result */}
            {audioUrl && (
              <div className="space-y-6">
                <div className="bg-white p-8 rounded-3xl border-2 border-indigo-100 shadow-2xl text-center space-y-6">
                  <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mx-auto">
                    <i className="fa-solid fa-check text-3xl text-indigo-600"></i>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-black text-slate-800 tracking-tight">Your Snippet is Ready</h3>
                    <p className="text-slate-500">High-fidelity multi-voice audio generated successfully.</p>
                  </div>
                  
                  <div className="max-w-sm mx-auto p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <audio controls className="w-full" src={audioUrl} />
                  </div>

                  <div className="flex items-center justify-center gap-3">
                    <a
                      href={audioUrl}
                      download={`snippet-${selectedExp.toLowerCase()}-${Date.now()}.wav`}
                      className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center gap-2"
                    >
                      <i className="fa-solid fa-download"></i>
                      Download WAV
                    </a>
                    <button
                      onClick={() => setAudioUrl(null)}
                      className="px-6 py-2.5 text-slate-600 font-bold hover:bg-slate-100 rounded-xl transition-all"
                    >
                      Regenerate
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-6 rounded-2xl border border-slate-100">
                     <h4 className="font-bold mb-4 text-slate-400 uppercase text-xs tracking-widest">Metadata</h4>
                     <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-500">Format</span>
                          <span className="font-medium text-slate-700">WAV (PCM 16-bit)</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-500">Sample Rate</span>
                          <span className="font-medium text-slate-700">24kHz</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-500">Speakers</span>
                          <span className="font-medium text-slate-700">{speakers.length}</span>
                        </div>
                     </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl border border-slate-100 flex items-center justify-center text-center">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-500">Want another version?</p>
                      <button onClick={() => setScript(null)} className="text-indigo-600 font-bold text-sm hover:underline">Change Experience Type</button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Persistent Call to Action for generating or resets */}
      {selectedExp && !audioUrl && (
        <div className="fixed bottom-0 inset-x-0 bg-white/80 backdrop-blur-lg border-t border-slate-200 p-4 flex justify-center z-40">
           <div className="max-w-4xl w-full flex items-center justify-between">
              <div className="flex items-center gap-2">
                 <span className="text-xs font-bold uppercase text-slate-400">Status:</span>
                 <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-600 animate-pulse">
                   {isGeneratingScript ? 'Writing...' : isGeneratingAudio ? 'Synthesizing...' : 'Ready'}
                 </span>
              </div>
              <button 
                onClick={reset}
                className="text-xs font-bold text-slate-500 hover:text-red-500 transition-colors uppercase tracking-widest"
              >
                Clear All
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default App;
