
import React from 'react';
import { ExperienceType, ExperienceConfig } from './types';

export const EXPERIENCES: ExperienceConfig[] = [
  {
    type: ExperienceType.PODCAST,
    title: "Podcast Discussion",
    description: "A dynamic back-and-forth conversation between two hosts analyzing the topic.",
    icon: "fa-microphone-lines",
    defaultSpeakers: [
      { id: 'host1', name: 'Alex', voice: 'Kore' },
      { id: 'host2', name: 'Jordan', voice: 'Puck' }
    ]
  },
  {
    type: ExperienceType.MONOLOGUE,
    title: "Video Monologue",
    description: "A direct-to-camera style delivery, perfect for educational or thought-leadership content.",
    icon: "fa-person-chalkboard",
    defaultSpeakers: [
      { id: 'solo', name: 'Speaker', voice: 'Zephyr' }
    ]
  },
  {
    type: ExperienceType.ANNOUNCEMENT,
    title: "Official Announcement",
    description: "Brief, professional, and clear delivery of news or updates.",
    icon: "fa-bullhorn",
    defaultSpeakers: [
      { id: 'announcer', name: 'Announcer', voice: 'Charon' }
    ]
  },
  {
    type: ExperienceType.KEYNOTE,
    title: "Sinek-Style Keynote",
    description: "Inspiring, rhythmic delivery starting with 'Why', building to a powerful 'How' and 'What'.",
    icon: "fa-lightbulb",
    defaultSpeakers: [
      { id: 'leader', name: 'Visionary', voice: 'Fenrir' }
    ]
  }
];

export const VOICES = ['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr'] as const;
