
import { GoogleGenAI, Type } from "@google/genai";
import { ExperienceType, ScriptLine, Speaker } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

/**
 * Generates a structured script based on the experience type and topic.
 */
export async function generateScript(
  topic: string, 
  experienceType: ExperienceType,
  speakers: Speaker[]
): Promise<ScriptLine[]> {
  const speakerNames = speakers.map(s => s.name).join(', ');
  
  const systemPrompt = `
    You are a professional scriptwriter. Generate a script for a ${experienceType} experience.
    The topic/source text is: "${topic}"
    The characters are: ${speakerNames}.
    
    Guidelines:
    - If it's a PODCAST, make it a natural conversation between ${speakerNames}.
    - If it's a MONOLOGUE, write it as a cohesive, engaging speech for ${speakers[0].name}.
    - If it's a KEYNOTE, follow a Simon Sinek style: Start with WHY, then HOW, then WHAT. Use powerful, short sentences.
    - If it's an ANNOUNCEMENT, keep it concise and authoritative.
    - Ensure the script directly uses insights from the source text.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "Write the script based on the guidelines.",
    config: {
      systemInstruction: systemPrompt,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          lines: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                speakerName: { type: Type.STRING },
                text: { type: Type.STRING }
              },
              required: ["speakerName", "text"]
            }
          }
        },
        required: ["lines"]
      }
    }
  });

  try {
    const data = JSON.parse(response.text);
    return data.lines.map((line: any) => {
      // Map speakerName back to speakerId
      const speaker = speakers.find(s => s.name.toLowerCase() === line.speakerName.toLowerCase()) || speakers[0];
      return {
        speakerId: speaker.id,
        text: line.text
      };
    });
  } catch (e) {
    console.error("Failed to parse script JSON", e);
    return [];
  }
}

/**
 * Encodes Uint8Array to Base64 string.
 */
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Decodes Base64 string to Uint8Array.
 */
function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Decodes raw PCM audio data into an AudioBuffer.
 */
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

/**
 * Generates multi-speaker audio from the script.
 */
export async function generateMultiSpeakerAudio(
  script: ScriptLine[],
  speakers: Speaker[]
): Promise<Blob> {
  // Format prompt for multi-speaker TTS
  const prompt = script.map(line => {
    const speaker = speakers.find(s => s.id === line.speakerId);
    return `${speaker?.name}: ${line.text}`;
  }).join('\n');

  const speakerVoiceConfigs = speakers.map(s => ({
    speaker: s.name,
    voiceConfig: {
      prebuiltVoiceConfig: { voiceName: s.voice }
    }
  }));

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Generate audio for this conversation:\n${prompt}` }] }],
    config: {
      responseModalities: ['AUDIO' as any],
      speechConfig: {
        multiSpeakerVoiceConfig: {
          speakerVoiceConfigs: speakerVoiceConfigs
        }
      } as any
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio data returned from Gemini");

  const audioBytes = decode(base64Audio);
  
  // Convert PCM to WAV for browser playback
  return new Blob([createWavHeader(audioBytes, 24000, 1)], { type: 'audio/wav' });
}

/**
 * Helper to wrap raw PCM data in a WAV header.
 */
function createWavHeader(pcmData: Uint8Array, sampleRate: number, numChannels: number): Uint8Array {
  const header = new ArrayBuffer(44);
  const view = new DataView(header);

  // RIFF identifier
  view.setUint32(0, 0x52494646, false); // "RIFF"
  view.setUint32(4, 36 + pcmData.length, true);
  view.setUint32(8, 0x57415645, false); // "WAVE"

  // fmt subchunk
  view.setUint32(12, 0x666d7420, false); // "fmt "
  view.setUint32(16, 16, true); // Size
  view.setUint16(20, 1, true); // Linear PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * numChannels * 2, true);
  view.setUint16(32, numChannels * 2, true);
  view.setUint16(34, 16, true); // Bits per sample

  // data subchunk
  view.setUint32(36, 0x64617461, false); // "data"
  view.setUint32(40, pcmData.length, true);

  const result = new Uint8Array(header.byteLength + pcmData.length);
  result.set(new Uint8Array(header), 0);
  result.set(pcmData, 44);
  return result;
}
